
/**
 * Write a description of class MadLibs here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MadLibs
{
    public static void main (String args[])
    {
        new MadLibs ();
    }
    
    public MadLibs ()
    {
        String madeup = IBIO.inputString ("Enter a madeup name ");
        String colour = IBIO.inputString ("Enter a colour ");
        String acolour = IBIO.inputString ("Enter another colour ");
        String food = IBIO.inputString ("Enter a name of any food (plural) ");
        String drink = IBIO.inputString ("Enter a name of a drink ");
        String place = IBIO.inputString ("Enter a name of any place ");
        String bug = IBIO.inputString ("Enter a name of an insect ");
        String adj = IBIO.inputString ("Enter any adjective ");
        String anything = IBIO.inputString ("Enter the name of an object ");
        
        System.out.println ("Once upon a time there was a monster named, "+madeup+ ".");
        System.out.println ("He had " +colour+ " dots and a "+acolour+ " tail.");
        System.out.println ("He ate "+food+ " and drank "+drink+ " everyday.");
        System.out.println ("Also, "+madeup+ " lived in " +place+ " with " +bug+ "s.");
        System.out.println ("He was a very " +adj+ " monster that loved " +anything+ "s.");
    }
}    
        
        
        